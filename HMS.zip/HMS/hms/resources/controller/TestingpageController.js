valourcabs.controller('TestingpageController', ['$scope', '$http', '$location', '$filter', '$rootScope','$timeout', function($scope, $http, $location, $filter, $rootScope, $timeout) {
/*	$('#slide-out').css("left", "0px")
*/}]);
