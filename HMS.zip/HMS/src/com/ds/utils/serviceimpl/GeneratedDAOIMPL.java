package com.ds.utils.serviceimpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ds.hms.constants.ApplicationLogging;
import com.ds.hms.pojo.Tblsequence;
import com.ds.utils.service.GenerateDAO;

@Component
public class GeneratedDAOIMPL implements GenerateDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public String getUserId() throws Exception {

		String 			SQL_NEARMISS 	= null;
		String 			tableId 		= null;
		Query 			SQL_QUERY 		= null;
		String 			id 				= null;
		Session         session         = null;
		Tblsequence     tblsequence     = null;
		
		try {
			
			session = this.sessionFactory.openSession();

			SQL_NEARMISS = "SELECT USERID FROM tblsequence WHERE ID = :ID ";
			SQL_QUERY = session.createSQLQuery(SQL_NEARMISS);
			SQL_QUERY.setParameter("ID", 1);
			tableId = (String) SQL_QUERY.uniqueResult();
			int num = Integer.parseInt(tableId.substring(3));
			if (num == 999) {
				id = "UID" + "001";
			} else {
				num++;
				String temp1 = num + "";
				if (temp1.length() < 3) {
					int s = temp1.length();
					for (int i = 0; i < (3 - s); i++) {
						temp1 = "0" + temp1;
					}
				}
				id = tableId.substring(0, 3) + temp1;
				
				tblsequence = (Tblsequence) session.load(Tblsequence.class, 1);
				if(tblsequence != null) {
					tblsequence.setUserId(id);
					session.merge(tblsequence);
				}
			}
			
			session.flush();
			session.clear();
			
		} catch (Exception e) {
			ApplicationLogging.publish("Exception generated while getting table id is " + e.getMessage(), e);
			throw new Exception("Exception generated while getting table id is " + e.getMessage(), e);
		}

		return id;
	}

	@Override
	public String getPatientCode() throws Exception {
			
		String 			SQL_PATIENT_CODE   	= null;
		String 			tableId 		    = null;
		Query 			SQL_QUERY 		    = null;
		String 			id 				    = null;
		Session         session             = null;
		
		try {

			session = sessionFactory.openSession();
			
			SQL_PATIENT_CODE = "SELECT PATIENT_CODE FROM tblsequence WHERE ID = :ID ";
			SQL_QUERY = session.createSQLQuery(SQL_PATIENT_CODE);
			SQL_QUERY.setParameter("ID", 1);
			tableId = (String) SQL_QUERY.uniqueResult();
			int num = Integer.parseInt(tableId.substring(3));
			if (num == 999) {
				id = "PID" + "001";
			} else {
				num++;
				String temp1 = num + "";
				if (temp1.length() < 3) {
					int s = temp1.length();
					for (int i = 0; i < (3 - s); i++) {
						temp1 = "0" + temp1;
					}
				}
				id = tableId.substring(0, 3) + temp1;
			}
			
		} catch (Exception e) {
			ApplicationLogging.publish("Exception generated while getting table id is " + e.getMessage(), e);
			throw new Exception("Exception generated while getting table id is " + e.getMessage(), e);
		}

		return id;
	}
}
