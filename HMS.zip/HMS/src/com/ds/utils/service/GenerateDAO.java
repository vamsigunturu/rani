package com.ds.utils.service;

import com.ds.hms.constants.ApplicationConstants;

public interface GenerateDAO extends ApplicationConstants {

	public String getUserId() throws Exception;
	
	String getPatientCode() throws Exception;
	
}
