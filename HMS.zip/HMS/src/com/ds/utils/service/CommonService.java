package com.ds.utils.service;

import org.hibernate.Session;

public interface CommonService {

	/**
	 * HIBERNATE QUERY TEMPLATE LIBRARY declaration
	 * 
	 */
	public <E> E findByPropertiessingleentity(String hql, Object[] params, Session session);

	public <E> E findByPropertiessingleentityByName(Class<E> entityName, String propertyName, Object value, Session session);

	public <E> E findByPropertiessingleentityByNameWITHSEARCH(Class<E> entityName, String propertyName, Object value, Session session);

	public <E> E findByPropertiesList(String hql, Object[] params, Session session);

	public <E> E findByPropertiesListByName(Class<E> entityName, String propertyName, Object value, Session session);

	public <E> E findByPropertiesListByNameWITHSEARCH(Class<E> entityName, String propertyName, Object value, Session session);

	public <E> E loadAll(Class<E> entityName, Session session, String param);

	/**
	 * SQL QUERY TEMPLATE LIBRARY declaration
	 * 
	 */

	public <E> E nativeSQLQuery(String query, Class<E> entityClass, Session session);

	public <E> E nativeSQLQuery(String query, Session session);

	public <E> E nativeSQLQueryUniqueObject(String query, Session session);

	public <E> E nativeSQLQuerywithparameters(String query, Class<E> entityClass, Object[] params, Session session);
	
	public <E> E nativeSQLQuerywithparametersUniqueResult(String query, Class<E> entityClass, Object[] params, Session session);

	public <E> E nativeSQLQuerywithparameters(String query, Object[] params, Session session);

	public <E> E nativeSQLQuerywithparametersSingleEntity(String query, Object[] params, Session session);

	public <E> E nativeSQLQueryWithSingleColonmparma(String query, Object value, Session session);

	public <E> E nativeSQLQueryWithSingleColonmparmaWIthSingleEntity(String query, Object value, Session session);

	public <E> E nativeSQLQueryUniqueObjectTransformation(String query, Class<E> entityClass, Session session);

}
