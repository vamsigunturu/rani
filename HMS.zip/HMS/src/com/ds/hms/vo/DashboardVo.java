package com.ds.hms.vo;

public class DashboardVo {

}
