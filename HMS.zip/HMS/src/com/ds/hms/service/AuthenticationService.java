package com.ds.hms.service;

import com.ds.hms.po.LoginPO;
import com.ds.hms.pojo.Tbluser;

public interface AuthenticationService {

	/**
	 * 
	 * @param loginPO
	 * @return
	 * @throws Exception
	 */
	Tbluser authenticatUser(LoginPO loginPO) throws Exception;

}
