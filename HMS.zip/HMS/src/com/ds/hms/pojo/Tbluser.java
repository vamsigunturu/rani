package com.ds.hms.pojo;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "tbluser")
@XmlRootElement
public class Tbluser implements java.io.Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userid;
	private Timestamp lastLoginDate;
	private Timestamp lastLoginFailedDate;
	private String lastLoginIp;
	private String firstName;
	private String middleName;
	private String lastName;
	private String username;
	private String password;
	private Integer loginFailedAttempts;
	private Integer loginfirst;
	private Integer loginstatus;
	private String profilePic;
	private Tbladdress tbladdress;
	private Tblstatusmaster tblstatusmaster;
	private Tblrole tblrole;
	private String isStaff;
	private String isDoctor;
	private String isPatient;

	private boolean isLoggedIn;

	// Constructors

	/** default constructor */
	public Tbluser() {
	}

	// Property accessors
	@Id
	@Column(name = "USERID", unique = true, nullable = false)
	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Column(name = "LAST_LOGIN_DATE", length = 19)
	public Timestamp getLastLoginDate() {
		return this.lastLoginDate;
	}

	public void setLastLoginDate(Timestamp lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	@Column(name = "LAST_LOGIN_FAILED_DATE", length = 19)
	public Timestamp getLastLoginFailedDate() {
		return this.lastLoginFailedDate;
	}

	public void setLastLoginFailedDate(Timestamp lastLoginFailedDate) {
		this.lastLoginFailedDate = lastLoginFailedDate;
	}

	@Column(name = "LAST_LOGIN_IP")
	public String getLastLoginIp() {
		return this.lastLoginIp;
	}

	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}

	@Column(name = "FIRST_NAME")
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Column(name = "LAST_NAME")
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Column(name = "USERNAME")
	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "PASSWORD")
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "LOGIN_FAILED_ATTEMPTS")
	public Integer getLoginFailedAttempts() {
		return this.loginFailedAttempts;
	}

	public void setLoginFailedAttempts(Integer loginFailedAttempts) {
		this.loginFailedAttempts = loginFailedAttempts;
	}

	@Column(name = "LOGINFIRST")
	public Integer getLoginfirst() {
		return this.loginfirst;
	}

	public void setLoginfirst(Integer loginfirst) {
		this.loginfirst = loginfirst;
	}

	@Column(name = "PROFILE_PIC")
	public String getProfilePic() {
		return this.profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public void setTblstatusmaster(Tblstatusmaster tblstatusmaster) {
		this.tblstatusmaster = tblstatusmaster;
	}

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUSMASTERID")
	public Tblstatusmaster getTblstatusmaster() {
		return tblstatusmaster;
	}


	/**
	 * @param isLoggedIn
	 *            the isLoggedIn to set
	 */
	public void setLoggedIn(boolean isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}

	/**
	 * @return the isLoggedIn
	 */
	@Transient
	public boolean isLoggedIn() {
		return isLoggedIn;
	}
	
	@Column(name = "LOGIN_STATUS")
	public Integer getLoginstatus() {
		return loginstatus;
	}

	public void setLoginstatus(Integer loginstatus) {
		this.loginstatus = loginstatus;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ROLE_ID")
	public Tblrole getTblrole() {
		return tblrole;
	}

	public void setTblrole(Tblrole tblrole) {
		this.tblrole = tblrole;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ADDRESSID")
	public Tbladdress getTbladdress() {
		return tbladdress;
	}

	public void setTbladdress(Tbladdress tbladdress) {
		this.tbladdress = tbladdress;
	}
	
	@Column(name = "MIDDLE_NAME")
	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@Column(name = "IS_STAFF")
	public String getIsStaff() {
		return isStaff;
	}

	public void setIsStaff(String isStaff) {
		this.isStaff = isStaff;
	}
	
	@Column(name = "IS_DOCTOR")
	public String getIsDoctor() {
		return isDoctor;
	}

	@Column(name = "IS_PATIENT")
	public void setIsDoctor(String isDoctor) {
		this.isDoctor = isDoctor;
	}

	public String getIsPatient() {
		return isPatient;
	}

	public void setIsPatient(String isPatient) {
		this.isPatient = isPatient;
	}
}