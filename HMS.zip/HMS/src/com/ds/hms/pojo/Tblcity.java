package com.ds.hms.pojo;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tblcity")
public class Tblcity implements java.io.Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	private Integer cityid;
	private Tblstate tblstate;
	private Tblcountry tblcountry;
	private String cityname;
	private Double latitude;
	private Double longitude;

	// Constructors

	/** default constructor */
	public Tblcity() {
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "CITYID", unique = true, nullable = false)
	public Integer getCityid() {
		return this.cityid;
	}

	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATEID")
	public Tblstate getTblstate() {
		return this.tblstate;
	}

	public void setTblstate(Tblstate tblstate) {
		this.tblstate = tblstate;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COUNTRYID")
	public Tblcountry getTblcountry() {
		return this.tblcountry;
	}

	public void setTblcountry(Tblcountry tblcountry) {
		this.tblcountry = tblcountry;
	}

	@Column(name = "CITYNAME")
	public String getCityname() {
		return this.cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	@Column(name = "LATITUDE", precision = 22, scale = 0)
	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	@Column(name = "LONGITUDE", precision = 22, scale = 0)
	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
}