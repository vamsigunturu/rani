package com.ds.hms.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "tblpateint")
public class Tblpatient implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String patientCode;
	private Tbldoctor tbldoctor;
	private Tbladdress tbladdress;
	private String dateAndTime;
	private String insuranceName;
	private String insuranceId;
	private Tblstatusmaster tblstatusmaster;
	private String status;
	
	@Id
	@Column(name = "PATIENT_CODE", nullable = false, unique = true)
	public String getPatientCode() {
		return patientCode;
	}
	public void setPatientCode(String patientCode) {
		this.patientCode = patientCode;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DOCTOR_ID")
	public Tbldoctor getTbldoctor() {
		return tbldoctor;
	}
	public void setTbldoctor(Tbldoctor tbldoctor) {
		this.tbldoctor = tbldoctor;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ADDRESSID")
	public Tbladdress getTbladdress() {
		return tbladdress;
	}
	public void setTbladdress(Tbladdress tbladdress) {
		this.tbladdress = tbladdress;
	}
	
	@Column(name = "DATE_TIME")
	public String getDateAndTime() {
		return dateAndTime;
	}
	public void setDateAndTime(String dateAndTime) {
		this.dateAndTime = dateAndTime;
	}
	
	@Column(name = "INSURANCE_NAME")
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	@Column(name = "INSURANCE_ID")
	public String getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(String insuranceId) {
		this.insuranceId = insuranceId;
	}
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUSMASTERID")
	public Tblstatusmaster getTblstatusmaster() {
		return tblstatusmaster;
	}
	public void setTblstatusmaster(Tblstatusmaster tblstatusmaster) {
		this.tblstatusmaster = tblstatusmaster;
	}
	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
