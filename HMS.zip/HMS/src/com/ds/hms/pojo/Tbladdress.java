package com.ds.hms.pojo;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbladdress")
public class Tbladdress implements java.io.Serializable, Cloneable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer addressid;
	private Tbluser tbluser;
	private String  fixedLine;
	private String  doorNum;
	private String  streetAddress;
	private String  landmark;
	private String  gender;
	private String  age;
	private String  postalcode;
	private String  phoneNum;
	private String  mobileNum;
	private String  emailid;
	private String  alternativeEmail;
	private String  dob;
	private String city;
	private String country;
	private String state;

	// Constructors

	/** default constructor */
	public Tbladdress() {
	}

	/** full constructor */
	public Tbladdress(Tbluser tbluser, String fixedLine,
			String doorNum, String streetAddress, String landmark, String gender, String postalcode, String phoneNum,
			String mobileNum, String emailid, String alternativeEmail) {
		this.tbluser = tbluser;
		this.fixedLine = fixedLine;
		this.doorNum = doorNum;
		this.streetAddress = streetAddress;
		this.landmark = landmark;
		this.gender = gender;
		this.postalcode = postalcode;
		this.phoneNum = phoneNum;
		this.mobileNum = mobileNum;
		this.emailid = emailid;
		this.alternativeEmail = alternativeEmail;
	}

	// Property accessors
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ADDRESSID", unique = true, nullable = false)
	public Integer getAddressid() {
		return this.addressid;
	}

	public void setAddressid(Integer addressid) {
		this.addressid = addressid;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "USERID")
	public Tbluser getTbluser() {
		return this.tbluser;
	}

	public void setTbluser(Tbluser tbluser) {
		this.tbluser = tbluser;
	}

	@Column(name = "FIXED_LINE")
	public String getFixedLine() {
		return this.fixedLine;
	}

	public void setFixedLine(String fixedLine) {
		this.fixedLine = fixedLine;
	}

	@Column(name = "DOOR_NUM")
	public String getDoorNum() {
		return this.doorNum;
	}

	public void setDoorNum(String doorNum) {
		this.doorNum = doorNum;
	}

	@Column(name = "STREET_ADDRESS")
	public String getStreetAddress() {
		return this.streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	@Column(name = "LANDMARK")
	public String getLandmark() {
		return this.landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	@Column(name = "GENDER")
	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Column(name = "POSTALCODE")
	public String getPostalcode() {
		return this.postalcode;
	}

	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}

	@Column(name = "PHONE_NUM")
	public String getPhoneNum() {
		return this.phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	@Column(name = "MOBILE_NUM")
	public String getMobileNum() {
		return this.mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	@Column(name = "EMAILID")
	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	@Column(name = "ALTERNATIVE_EMAIL")
	public String getAlternativeEmail() {
		return this.alternativeEmail;
	}

	public void setAlternativeEmail(String alternativeEmail) {
		this.alternativeEmail = alternativeEmail;
	}

	@Column(name = "DOB")
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	@Column(name = "AGE")
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	@Column(name = "CITY")
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "COUNTRY")
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Column(name = "STATE")
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}