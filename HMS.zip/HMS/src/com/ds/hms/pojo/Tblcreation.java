package com.ds.hms.pojo;

import static javax.persistence.GenerationType.IDENTITY;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="tblcreation")
@XmlRootElement
public class Tblcreation implements java.io.Serializable , Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	private Integer creationid;
	private String createdByUserid;
	private String modifiedByUserid;
	private Timestamp createdDate;
	private Timestamp modifiedDate;

	// Constructors

	/** default constructor */
	public Tblcreation() {
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "CREATIONID", unique = true, nullable = false)
	public Integer getCreationid() {
		return this.creationid;
	}

	public void setCreationid(Integer creationid) {
		this.creationid = creationid;
	}

	@Column(name = "CREATED_BY_USERID")
	public String getCreatedByUserid() {
		return this.createdByUserid;
	}

	public void setCreatedByUserid(String createdByUserid) {
		this.createdByUserid = createdByUserid;
	}

	@Column(name = "MODIFIED_BY_USERID")
	public String getModifiedByUserid() {
		return this.modifiedByUserid;
	}

	public void setModifiedByUserid(String modifiedByUserid) {
		this.modifiedByUserid = modifiedByUserid;
	}

	@Column(name = "CREATED_DATE", length = 19)
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "MODIFIED_DATE", length = 19)
	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}

	
