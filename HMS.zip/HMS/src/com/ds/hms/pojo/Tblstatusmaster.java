package com.ds.hms.pojo;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblstatusmaster")
public class Tblstatusmaster implements java.io.Serializable, Cloneable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer statusmasterid;
	private String description;
	private String statusName;

	// Constructors

	/** default constructor */
	public Tblstatusmaster() {
	}

	public Tblstatusmaster(Integer statusmasterid) {
		this.statusmasterid = statusmasterid;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "STATUSMASTERID", unique = true, nullable = false)
	public Integer getStatusmasterid() {
		return this.statusmasterid;
	}

	public void setStatusmasterid(Integer statusmasterid) {
		this.statusmasterid = statusmasterid;
	}

	@Column(name = "DESCRIPTION")
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "STATUS_NAME")
	public String getStatusName() {
		return this.statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
}
