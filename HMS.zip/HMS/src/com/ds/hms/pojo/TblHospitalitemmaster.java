package com.ds.hms.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "tblhospitalitemmaster")
public class TblHospitalitemmaster implements Serializable, Cloneable {
	
	private static final long serialVersionUID = 1L;
	
    private Integer labItemMasterId;
    private String serviceCode;
    private String serviceName;
    private String unitName;
    private String ratePerunit;
    private TblCategory tblCategory;
    private Tblstatusmaster tblstatusmaster;
    private Tblcreation tblcreation;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HOSPITAL_MASTER_ID", nullable = false, unique = true)
	public Integer getLabItemMasterId() {
		return labItemMasterId;
	}
	public void setLabItemMasterId(Integer labItemMasterId) {
		this.labItemMasterId = labItemMasterId;
	}
	
	@Column(name = "SERVICE_CODE")
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	
	@Column(name = "SERVICE_NAME")
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	@Column(name = "UNIT_NAME")
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	
	@Column(name = "RATE_PER_UNIT")
	public String getRatePerunit() {
		return ratePerunit;
	}
	public void setRatePerunit(String ratePerunit) {
		this.ratePerunit = ratePerunit;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CATEGORY_ID")
	public TblCategory getTblCategory() {
		return tblCategory;
	}
	public void setTblCategory(TblCategory tblCategory) {
		this.tblCategory = tblCategory;
	}
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUSMASTERID")
	public Tblstatusmaster getTblstatusmaster() {
		return tblstatusmaster;
	}
	public void setTblstatusmaster(Tblstatusmaster tblstatusmaster) {
		this.tblstatusmaster = tblstatusmaster;
	}
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATIONID")
	public Tblcreation getTblcreation() {
		return tblcreation;
	}
	public void setTblcreation(Tblcreation tblcreation) {
		this.tblcreation = tblcreation;
	}
}
