package com.ds.hms.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "tblcategory")
public class TblCategory implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer categoryID;
	private String serviceCategory;
	private Tblcreation tblcreation;
	private Tblstatusmaster tblstatusmaster;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CATEGORY_ID", nullable = false, unique = true)
	public Integer getCategoryID() {
		return categoryID;
	}
	public void setCategoryID(Integer categoryID) {
		this.categoryID = categoryID;
	}
	
	@Column(name = "SERVICE_CATEGORY")
	public String getServiceCategory() {
		return serviceCategory;
	}
	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUSMASTERID")
	public Tblstatusmaster getTblstatusmaster() {
		return tblstatusmaster;
	}
	public void setTblstatusmaster(Tblstatusmaster tblstatusmaster) {
		this.tblstatusmaster = tblstatusmaster;
	}
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATIONID")
	public Tblcreation getTblcreation() {
		return tblcreation;
	}
	public void setTblcreation(Tblcreation tblcreation) {
		this.tblcreation = tblcreation;
	}
	
	
}
