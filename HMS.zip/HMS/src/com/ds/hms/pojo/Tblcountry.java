package com.ds.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblcountry")
public class Tblcountry implements java.io.Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	private String countryid;
	private String countryname;
	private String localname;
	private String webcode;
	private String region;
	private String continent;
	private Double latitude;
	private Double longitude;
	private Double surfacearea;
	private Integer population;

	// Constructors

	/** default constructor */
	public Tblcountry() {
	}

	// Property accessors
	@Id
	@Column(name = "COUNTRYID", unique = true, nullable = false)
	public String getCountryid() {
		return this.countryid;
	}

	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}

	@Column(name = "COUNTRYNAME")
	public String getCountryname() {
		return this.countryname;
	}

	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}

	@Column(name = "LOCALNAME")
	public String getLocalname() {
		return this.localname;
	}

	public void setLocalname(String localname) {
		this.localname = localname;
	}

	@Column(name = "WEBCODE")
	public String getWebcode() {
		return this.webcode;
	}

	public void setWebcode(String webcode) {
		this.webcode = webcode;
	}

	@Column(name = "REGION")
	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@Column(name = "CONTINENT")
	public String getContinent() {
		return this.continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	@Column(name = "LATITUDE", precision = 22, scale = 0)
	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	@Column(name = "LONGITUDE", precision = 22, scale = 0)
	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	@Column(name = "SURFACEAREA", precision = 10)
	public Double getSurfacearea() {
		return this.surfacearea;
	}

	public void setSurfacearea(Double surfacearea) {
		this.surfacearea = surfacearea;
	}

	@Column(name = "POPULATION")
	public Integer getPopulation() {
		return this.population;
	}

	public void setPopulation(Integer population) {
		this.population = population;
	}
}