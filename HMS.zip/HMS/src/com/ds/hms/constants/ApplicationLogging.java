package com.ds.hms.constants;

import com.ds.hms.utils.Logging;

public class ApplicationLogging extends Logging {

	// error
	public static void error(Object messgae, Throwable t) {
		Logging.error(messgae, t);
	}

	public static void setAppender(String applicationPath) {
		
		try {
			// System.out.println("Application Path :"+applicationPath);
			Logging.setErrorAppender(applicationPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
