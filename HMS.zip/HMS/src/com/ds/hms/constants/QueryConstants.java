package com.ds.hms.constants;

import java.io.Serializable;

public interface QueryConstants extends Serializable, Cloneable {
	
	
	public static final String SQL_QUERY_INCIDENT_DETAILS_PERMISSION_FOR_FIELDS = "select "
			+ "MAX(CASE WHEN MASTERID = 17 THEN ISACTIVE END) title, "
			+ "MAX(CASE WHEN MASTERID = 18 THEN ISACTIVE END) incidentDate, "
			+ "MAX(CASE WHEN MASTERID = 19 THEN ISACTIVE END) incidentTime, "
			+ "MAX(CASE WHEN MASTERID = 20 THEN ISACTIVE END) description, "
			+ "MAX(CASE WHEN MASTERID = 21 THEN ISACTIVE END) actionTaken, "
			+ "MAX(CASE WHEN MASTERID = 22 THEN ISACTIVE END) classification, "
			+ "MAX(CASE WHEN MASTERID = 23 THEN ISACTIVE END) severity, "
			+ "MAX(CASE WHEN MASTERID = 24 THEN ISACTIVE END) classificationA, "
			+ "MAX(CASE WHEN MASTERID = 25 THEN ISACTIVE END) classificationB, "
			+ "MAX(CASE WHEN MASTERID = 26 THEN ISACTIVE END) classificationC, "
			+ "MAX(CASE WHEN MASTERID = 27 THEN ISACTIVE END) classificationD, "
			+ "MAX(CASE WHEN MASTERID = 28 THEN ISACTIVE END) organisationalUnit, "
			+ "MAX(CASE WHEN MASTERID = 29 THEN ISACTIVE END) offsiteLocation, "
			+ "MAX(CASE WHEN MASTERID = 30 THEN ISACTIVE END) add1, "
			+ "MAX(CASE WHEN MASTERID = 31 THEN ISACTIVE END) add2, "
			+ "MAX(CASE WHEN MASTERID = 32 THEN ISACTIVE END) country, "
			+ "MAX(CASE WHEN MASTERID = 33 THEN ISACTIVE END) state, "
			+ "MAX(CASE WHEN MASTERID = 34 THEN ISACTIVE END) city, "
			+ "MAX(CASE WHEN MASTERID = 35 THEN ISACTIVE END) posatlCode, "
			+ "MAX(CASE WHEN MASTERID = 36 THEN ISACTIVE END) alcoholTesting "
			+ "FROM tblincidentfieldmaster group by STATUSMASTERID";
}
