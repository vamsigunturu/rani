package com.ds.hms.constants;

public interface ApplicationConstants {
	
	String LOG_PATH = "C:/HMS/";
	String FILE_PATH = "/home/HMS/confidential";
	
	public final Integer PARENT_NODE = 0;
	public final Integer ACTIVE = 1;
	public final Integer DELETE = 2;
	public final Integer DRAFT 	= 3;
	public final Integer INVESTIGATION 	= 4;
	public final Integer CLOSED 	= 5;
	public final Integer Under_Investigation 	= 6;
	
	//incident management Application flow
	
	public final Integer NEED_TO_BE_FILLED = 100;
	public final Integer PRIOR_AUTH = 101;
	public final Integer PATIENT_ASSIST = 102;
	public final Integer APPROVED = 103;
	public final Integer CANCELLED = 104;
	public final Integer BUY_AND_BILL = 106;
	public final Integer NON_MATCHED_PHARMACY = 112;
	public final Integer PLAN_BENEFITS_EXCLUSION = 110;
	public final Integer MD_NOTIFIED = 113;
	public final Integer RX_SENT_TO_SP = 114;
	public final Integer DRUG_SUBSTITUTION = 115;
	public final Integer PRIORAUTH_APPEAL = 116;
	
	public final Integer SHOW = 4;
	public final Integer HIDE = 5;
	public final Integer SAVE_DRAFT = 6;
	public final Integer REFILL = 105;
	public final Integer WAITING_ON_ERX = 99;
	
	
		
}
