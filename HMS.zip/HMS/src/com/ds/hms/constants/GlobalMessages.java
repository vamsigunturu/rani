package com.ds.hms.constants;

import java.util.ResourceBundle;

public interface GlobalMessages {

	ResourceBundle applicationBundle = ResourceBundle.getBundle("application");
	ResourceBundle mailBundle = ResourceBundle.getBundle("mail");
	ResourceBundle errorBundle = ResourceBundle.getBundle("error");

	public final String INCIDENT_LOAD_PATH = "http://127.0.0.1:8080/EHS/incident/";
	public final String PROFILE_LOAD_PATH = "http://127.0.0.1:8080/EHS/profile/";

	public final String LOG_PATH = applicationBundle.getString("app.logPath");
	public final String PROFILE_PATH = applicationBundle.getString("app.profile");
	public final String INCIDENT_PATH = applicationBundle.getString("app.incident");

	public static final String INTERNAL_PROBLEM_ERROR = errorBundle.getString("intername.message").trim();

	public static final String SUCCESS_DETAILS_MESSAGE = errorBundle.getString("success.message").trim();
	
	public static final String DRAFT_DETAILS_MESSAGE = errorBundle.getString("draft.message").trim();
	
	public static final String DUPLICATE_DETAILS_MESSAGE = errorBundle.getString("duplicate.message").trim();

	public static final String UPDATE_DETAILS_MESSAGE = errorBundle.getString("update.message").trim();

}
