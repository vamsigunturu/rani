package com.ds.hms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.hms.dao.MasterDao;
import com.ds.hms.po.CategoryMasterPO;
import com.ds.hms.po.DoctorPO;
import com.ds.hms.po.HospitalItemMasterPO;
import com.ds.hms.po.PatientPO;
import com.ds.hms.pojo.TblCategory;
import com.ds.hms.pojo.Tbldoctor;
import com.ds.hms.pojo.Tblpatient;
import com.ds.hms.pojo.Tbluser;
import com.ds.hms.service.MasterService;
import com.ds.utils.service.GenerateDAO;

@Service
public class MasterServiceImpl implements MasterService {
	
	@Autowired
	private MasterDao masterDao;
	
	@Autowired
	private GenerateDAO generateDAO;

	@Override
	public String saveDoctorDetails(DoctorPO doctorPO, Tbluser user) throws Exception {

		return this.masterDao.saveDoctorDetails(doctorPO, user);
	}

	@Override
	public List<Tbldoctor> fetchDoctorDetails(Tbluser user) throws Exception {
		
		return this.masterDao.fetchDoctorDetails(user);
	}

	@Override
	public String savePatientDetails(PatientPO patientPO, Tbluser user) throws Exception {

		return this.masterDao.savePatientDetails(patientPO, user);
	}

	@Override
	public String fetchPatientCode(Tbluser user) throws Exception {

		return this.generateDAO.getPatientCode();
	}

	@Override
	public List<Tblpatient> fetchPatientDetails(Tbluser user) throws Exception {
		
		return this.masterDao.fetchPatientDetails(user);
	}

	@Override
	public String saveCategoryMasterDetails(CategoryMasterPO categoryMasterPO, Tbluser user) throws Exception {

		return this.masterDao.saveCategoryMasterDetails(categoryMasterPO, user);
	}

	@Override
	public List<TblCategory> fetchCategoryMasterDetails(Tbluser user) throws Exception {

		return this.masterDao.fetchCategoryMasterDetails(user);
	}

	@Override
	public String saveHospitalItemMasterDetails(HospitalItemMasterPO hospitalItemMasterPO, Tbluser user) throws Exception {
		
		return this.masterDao.saveHospitalItemMasterDetails(hospitalItemMasterPO, user);
	}

}
