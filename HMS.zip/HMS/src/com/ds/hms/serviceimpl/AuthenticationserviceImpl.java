package com.ds.hms.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.hms.dao.AuthenticationDAO;
import com.ds.hms.po.LoginPO;
import com.ds.hms.pojo.Tbluser;
import com.ds.hms.service.AuthenticationService;

@Service
public class AuthenticationserviceImpl implements AuthenticationService {

	@Autowired
	private AuthenticationDAO authenticationDAO;

	/**
	 * 
	 */
	public Tbluser authenticatUser(LoginPO loginPO) throws Exception {

		return this.authenticationDAO.authenticatUser(loginPO);
	}

}
