package com.ds.hms.po;

public class PatientPO {
	
	private String lastName;

    private String patientCode;

    private String location;

    private String status;

    private String state;

    private String date;

    private String country;

    private String city;

    private String pincode;

    private String middleName;

    private String insurenceName;

    private String phoneNumber;

    private String doctorId;

    private String address;

    private String age;

    private String gender;

    private String firstName;

    private String mobileNumber;

    private String insurenceId;


		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getPatientCode() {
			return patientCode;
		}

		public void setPatientCode(String patientCode) {
			this.patientCode = patientCode;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getPincode() {
			return pincode;
		}

		public void setPincode(String pincode) {
			this.pincode = pincode;
		}

		public String getMiddleName() {
			return middleName;
		}

		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}


		public String getInsurenceName() {
			return insurenceName;
		}

		public void setInsurenceName(String insurenceName) {
			this.insurenceName = insurenceName;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public String getDoctorId() {
			return doctorId;
		}

		public void setDoctorId(String doctorId) {
			this.doctorId = doctorId;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getAge() {
			return age;
		}

		public void setAge(String age) {
			this.age = age;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public String getInsurenceId() {
			return insurenceId;
		}

		public void setInsurenceId(String insurenceId) {
			this.insurenceId = insurenceId;
		}
	    
	    
	    

}
