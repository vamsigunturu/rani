package com.ds.hms.po;

public class CategoryMasterPO {

	 private String serviceCategory;

	public String getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}
}
