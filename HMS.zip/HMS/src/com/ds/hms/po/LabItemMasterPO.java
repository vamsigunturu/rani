package com.ds.hms.po;

public class LabItemMasterPO {

}
