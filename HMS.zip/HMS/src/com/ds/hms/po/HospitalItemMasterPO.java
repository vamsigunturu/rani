package com.ds.hms.po;

public class HospitalItemMasterPO {

	private String serviceName;
    private String unitName;
    private String ratePerUnit;
    private String serviceCode;
    private String selectCategoryName;

    public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public String getRatePerUnit() {
		return ratePerUnit;
	}
	public void setRatePerUnit(String ratePerUnit) {
		this.ratePerUnit = ratePerUnit;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getSelectCategoryName() {
		return selectCategoryName;
	}
	public void setSelectCategoryName(String selectCategoryName) {
		this.selectCategoryName = selectCategoryName;
	}
}
