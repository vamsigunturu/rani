package com.ds.hms.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ds.hms.constants.ApplicationLogging;
import com.ds.hms.dao.AuthenticationDAO;
import com.ds.hms.po.LoginPO;
import com.ds.hms.pojo.Tbluser;
import com.ds.hms.utils.AesEncrypt;
import com.ds.utils.service.CommonService;

@Component
public class AuthenticationDAOIMPL implements AuthenticationDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private CommonService commonService;

	@Autowired
	private SessionFactory sessionFactory;
	
	/**
	 * 
	 */
	public Tbluser authenticatUser(LoginPO loginPO) throws Exception {

		Tbluser 	tbluser 	= null;
		String 		passwordEnc = null;
		Object[] 	values 		= null;
		Session 	session 	= null;

		try {

			session = this.sessionFactory.openSession();
			passwordEnc = AesEncrypt.encrypt(loginPO.getPassword());
			values = new Object[3];
			values[0] = loginPO.getUserName();
			values[1] = passwordEnc;
			values[2] = ACTIVE;
			tbluser = (Tbluser) this.commonService.findByPropertiessingleentity("FROM Tbluser WHERE username = ? AND password = ? AND tblstatusmaster.statusmasterid = ?", values, session);

		} catch (HibernateException e) {
			ApplicationLogging.error("In authenticating the user Hibernate Exception generated is " + e.getMessage(), e);
			throw new Exception("In authenticating the user Hibernate Exception generated is " + e.getMessage(), e);
		} catch (Exception e) {
			ApplicationLogging.error("In authenticating the user Exception generated is " + e.getMessage(), e);
			throw new Exception("In authenticating the user Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (HibernateException hibe) {
				ApplicationLogging.error("In getting the Unique Object the HibernateException generated ~3~ is " + hibe.getMessage(),hibe);
			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return tbluser;
	}

}
