package com.ds.hms.daoimpl;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ds.hms.constants.ApplicationConstants;
import com.ds.hms.constants.ApplicationLogging;
import com.ds.hms.constants.GlobalMessages;
import com.ds.hms.dao.MasterDao;
import com.ds.hms.po.CategoryMasterPO;
import com.ds.hms.po.DoctorPO;
import com.ds.hms.po.HospitalItemMasterPO;
import com.ds.hms.po.PatientPO;
import com.ds.hms.pojo.TblCategory;
import com.ds.hms.pojo.TblHospitalitemmaster;
import com.ds.hms.pojo.Tbladdress;
import com.ds.hms.pojo.Tblcreation;
import com.ds.hms.pojo.Tbldoctor;
import com.ds.hms.pojo.Tblpatient;
import com.ds.hms.pojo.Tblsequence;
import com.ds.hms.pojo.Tblstatusmaster;
import com.ds.hms.pojo.Tbluser;
import com.ds.utils.service.CommonService;
import com.ds.utils.service.GenerateDAO;

@Component
public class MasterDaoImpl implements MasterDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private GenerateDAO generateDAO;
	
	@Autowired
	private CommonService commonService; 

	@Override
	public String saveDoctorDetails(DoctorPO doctorPO, Tbluser user) throws Exception {
		
		
		Tbluser 	tbluser 	= null;
		String      status      = null;
		Tbldoctor   tbldoctor   = null;
		Tbladdress  tbladdress  = null;
		Session 	session 	= null;
		String      userId      = null;

		try {

			session = this.sessionFactory.openSession();
			
			userId = this.generateDAO.getUserId(); 
			tbluser = new Tbluser();
			tbluser.setUserid(userId);
			tbluser.setFirstName(doctorPO.getFirstName());
			tbluser.setLastName(doctorPO.getLastName());
			tbluser.setMiddleName(doctorPO.getMiddleName());
			tbluser.setIsDoctor("true");
			session.save(tbluser);
			
			tbladdress = new Tbladdress();
			tbladdress.setStreetAddress(doctorPO.getAddress());
			tbladdress.setAge(doctorPO.getAge());
			tbladdress.setGender(doctorPO.getGender());
			tbladdress.setMobileNum(doctorPO.getMobileNumber());
			tbladdress.setEmailid(doctorPO.getEmailId());
			tbladdress.setPhoneNum(doctorPO.getPhoneNumber());
			tbladdress.setTbluser(tbluser);
			session.save(tbladdress);
			
			tbldoctor = new Tbldoctor();
			tbldoctor.setSpecializationType(doctorPO.getSpecializationType());
			tbldoctor.setDesignation(doctorPO.getDesignation());
			tbldoctor.setLicenseNumber(doctorPO.getLicenseNumber());
			tbldoctor.setQualification(doctorPO.getQualification());
			tbldoctor.setTbladdress(tbladdress);
			tbldoctor.setTblstatusmaster(new Tblstatusmaster(ApplicationConstants.ACTIVE));
			session.save(tbldoctor);
			
			session.flush();
			session.clear();
			
			status = GlobalMessages.SUCCESS_DETAILS_MESSAGE;

		}  catch (Exception e) {
			ApplicationLogging.error("In Saving the Doctor details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Saving the Doctor details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return status;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Tbldoctor> fetchDoctorDetails(Tbluser user) throws Exception {
		
		List<Tbldoctor>   tbldoctors   = null;
		Session 	session 	= null;
		Object[] params = null;

		try {

			session = this.sessionFactory.openSession();
			params = new Object[1];
			params[0] = ApplicationConstants.ACTIVE;
			tbldoctors = (List<Tbldoctor>) this.commonService.findByPropertiesList("FROM Tbldoctor WHERE  tblstatusmaster.statusmasterid = ?", params, session);

		}  catch (Exception e) {
			ApplicationLogging.error("In Fetching the Doctor details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Fetching the Doctor details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return tbldoctors;
	}

	@Override
	public String savePatientDetails(PatientPO patientPO, Tbluser user) throws Exception {

		Tbluser 	tbluser 	= null;
		String      status      = null;
		Tbldoctor   tbldoctor   = null;
		Tbladdress  tbladdress  = null;
		Tblpatient  tblpatient  = null;
		Session 	session 	= null;
		String      userId      = null;
		Object[]    params      = null;
		Tblsequence tblsequence = null;

		try {

			session = this.sessionFactory.openSession();
			
			userId = this.generateDAO.getUserId(); 
			tbluser = new Tbluser();
			tbluser.setUserid(userId);
			tbluser.setFirstName(patientPO.getFirstName());
			tbluser.setLastName(patientPO.getLastName());
			tbluser.setMiddleName(patientPO.getMiddleName());
			tbluser.setIsPatient("true");
			session.save(tbluser);
			
			tbladdress = new Tbladdress();
			tbladdress.setStreetAddress(patientPO.getAddress());
			tbladdress.setAge(patientPO.getAge());
			tbladdress.setGender(patientPO.getGender());
			tbladdress.setMobileNum(patientPO.getMobileNumber());
			tbladdress.setPhoneNum(patientPO.getPhoneNumber());
			tbladdress.setTbluser(tbluser);
			tbladdress.setCity(patientPO.getCity());
			tbladdress.setCountry(patientPO.getCountry());
			tbladdress.setState(patientPO.getState());
			session.save(tbladdress);
			
			tblpatient = new Tblpatient();
			tblpatient.setDateAndTime(patientPO.getDate());
			tblpatient.setInsuranceName(patientPO.getInsurenceName());
			tblpatient.setInsuranceId(patientPO.getInsurenceId());
			tblpatient.setPatientCode(patientPO.getPatientCode());
			tblpatient.setStatus(patientPO.getStatus());
			params = new Object[2];
			params[0] = Integer.parseInt(patientPO.getDoctorId());
			params[1] = ApplicationConstants.ACTIVE;
			tbldoctor = (Tbldoctor) this.commonService.findByPropertiessingleentity("FROM Tbldoctor WHERE doctorID = ? AND tblstatusmaster.statusmasterid = ?", params, session);
			if(tbldoctor != null) {
				tblpatient.setTbldoctor(tbldoctor);
			}
			tblpatient.setTbladdress(tbladdress);
			tblpatient.setTblstatusmaster(new Tblstatusmaster(ApplicationConstants.ACTIVE));
			session.save(tblpatient);
			
			tblsequence = (Tblsequence) session.load(Tblsequence.class, 1);
			if(tblsequence != null) {
				tblsequence.setPatientCode(patientPO.getPatientCode());
				session.update(tblsequence);
			}

			session.flush();
			session.clear();
			
			status = GlobalMessages.SUCCESS_DETAILS_MESSAGE;

		}  catch (Exception e) {
			ApplicationLogging.error("In Saving the Patient details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Saving the Patient details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return status;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Tblpatient> fetchPatientDetails(Tbluser user) throws Exception {

		List<Tblpatient>   tblpatients   = null;
		Session 	session 	= null;
		Object[] params = null;

		try {

			session = this.sessionFactory.openSession();
			params = new Object[1];
			params[0] = ApplicationConstants.ACTIVE;
			tblpatients = (List<Tblpatient>) this.commonService.findByPropertiesList("FROM Tblpatient WHERE  tblstatusmaster.statusmasterid = ?", params, session);

		}  catch (Exception e) {
			ApplicationLogging.error("In Fetching the Patient details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Fetching the Patient details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return tblpatients;
	}

	@Override
	public String saveCategoryMasterDetails(CategoryMasterPO categoryMasterPO, Tbluser user) throws Exception {
		
		String      status      = null;
		Session 	session 	= null;
		Tblcreation tblcreation = null;
		TblCategory tblCategory = null;

		try {

			session = this.sessionFactory.openSession();
			
		    tblcreation = new Tblcreation();
		    tblcreation.setCreatedByUserid(user.getUserid());
		    tblcreation.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		    tblcreation.setModifiedByUserid(user.getUserid());
		    tblcreation.setModifiedDate(new Timestamp(System.currentTimeMillis()));
		    session.save(tblcreation);
		    
		    tblCategory = new TblCategory();
		    tblCategory.setServiceCategory(categoryMasterPO.getServiceCategory());
		    tblCategory.setTblstatusmaster(new Tblstatusmaster(ApplicationConstants.ACTIVE));
		    tblCategory.setTblcreation(tblcreation);
		    session.save(tblCategory);
			
			session.flush();
			session.clear();
			
			status = GlobalMessages.SUCCESS_DETAILS_MESSAGE;

		}  catch (Exception e) {
			ApplicationLogging.error("In Saving the Category details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Saving the Category details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}
		return status;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TblCategory> fetchCategoryMasterDetails(Tbluser user) throws Exception {

		List<TblCategory>   tblCategories   = null;
		Session 	session 	= null;
		Object[] params = null;

		try {

			session = this.sessionFactory.openSession();
			params = new Object[1];
			params[0] = ApplicationConstants.ACTIVE;
			tblCategories = (List<TblCategory>) this.commonService.findByPropertiesList("FROM TblCategory WHERE  tblstatusmaster.statusmasterid = ?", params, session);

		}  catch (Exception e) {
			ApplicationLogging.error("In Fetching the Category Master details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Fetching the Category Master details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}

		return tblCategories;
	}

	@Override
	public String saveHospitalItemMasterDetails(HospitalItemMasterPO hospitalItemMasterPO, Tbluser user) throws Exception {
		
		String      status      = null;
		Session 	session 	= null;
		Tblcreation tblcreation = null;
		TblHospitalitemmaster tblHospitalitemmaster = null;
		TblCategory  tblCategory = null;

		try {

			session = this.sessionFactory.openSession();
			
		    tblcreation = new Tblcreation();
		    tblcreation.setCreatedByUserid(user.getUserid());
		    tblcreation.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		    tblcreation.setModifiedByUserid(user.getUserid());
		    tblcreation.setModifiedDate(new Timestamp(System.currentTimeMillis()));
		    session.save(tblcreation);
		    
		    tblHospitalitemmaster = new TblHospitalitemmaster();
		    tblHospitalitemmaster.setServiceName(hospitalItemMasterPO.getServiceName());
		    tblHospitalitemmaster.setServiceCode(hospitalItemMasterPO.getServiceCode());
		    tblHospitalitemmaster.setRatePerunit(hospitalItemMasterPO.getRatePerUnit());
		    tblHospitalitemmaster.setUnitName(hospitalItemMasterPO.getUnitName());
		    
		    tblCategory = (TblCategory) this.commonService.findByPropertiessingleentityByName(TblCategory.class, "categoryID", hospitalItemMasterPO.getSelectCategoryName(), session)
		    tblHospitalitemmaster.setTblstatusmaster(new Tblstatusmaster(ApplicationConstants.ACTIVE));
		    tblHospitalitemmaster.setTblcreation(tblcreation);
		    session.save(tblHospitalitemmaster);
			
			session.flush();
			session.clear();
			
			status = GlobalMessages.SUCCESS_DETAILS_MESSAGE;

		}  catch (Exception e) {
			ApplicationLogging.error("In Saving the Hospita Item Master details Exception generated is " + e.getMessage(), e);
			throw new Exception("In Saving the Hospita Item Master details Exception generated is " + e.getMessage(), e);
		} finally {

			try {

				if (session != null && session.isOpen())
					session.close();

			} catch (Exception e2) {
				ApplicationLogging.error("In getting the Unique Object the exception generated ~4~ is " + e2.getMessage(), e2);
			}
		}
		return status;
	}

}
