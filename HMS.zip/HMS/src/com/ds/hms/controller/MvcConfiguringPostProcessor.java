package com.ds.hms.controller;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * The HTTP Message converters are created automatically by Spring. To perform
 * additional configuration we use a bean post-processor.
 */

@SuppressWarnings("deprecation")
@Configuration
@EnableWebMvc
public class MvcConfiguringPostProcessor implements BeanPostProcessor {

	/**
	 * Enable pretty print on any bean of type
	 * {@link MappingJacksonHttpMessageConverter} or
	 * {@link MappingJackson2HttpMessageConverter}.
	 */
	public Object postProcessBeforeInitialization(Object bean, String name) throws BeansException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		//mapper.setSerializationInclusion(Include.NON_NULL);
		if (bean instanceof HttpMessageConverter<?>)

			if (bean instanceof MappingJacksonHttpMessageConverter) {
				((MappingJacksonHttpMessageConverter) bean).setPrettyPrint(true);
			} else if (bean instanceof MappingJackson2HttpMessageConverter) {
				((MappingJackson2HttpMessageConverter) bean).setPrettyPrint(true);
				((MappingJackson2HttpMessageConverter) bean).setObjectMapper(mapper);
			}

		return bean;
	}

	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// Nothing to do
		return bean;
	}

}
