package com.ds.hms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ds.hms.constants.ApplicationLogging;
import com.ds.hms.po.LoginPO;
import com.ds.hms.pojo.Tbluser;
import com.ds.hms.service.AuthenticationService;
import com.google.gson.JsonObject;

@Controller
public class AuthenticationController {

	@Autowired
	private AuthenticationService authenticationService;

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/scope/user", method = RequestMethod.GET, produces = { "application/xml", "application/json" })
	public @ResponseBody Tbluser getScopeofUser(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession(false);
		Tbluser user = (Tbluser) session.getAttribute("user");
		
		if (user != null) {
			return user;
		} else {
			return null;
		}
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/scope/clear", method = RequestMethod.GET)
	public @ResponseBody String deleteScopeofUser(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession(false);
		session.removeAttribute("user");
		JsonObject object = new JsonObject();
		object.addProperty("status", "success");
		return object.toString();
	}

	/**
	 * 
	 * @param loginPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/loginSubmit/user", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String loginStatus(@RequestBody LoginPO loginPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		Tbluser 	user 	= null;
		String 		status 	= null;
		JsonObject 	object 	= null;

		try {
			
			object = new JsonObject();
			if ((user = this.authenticationService.authenticatUser(loginPO)) != null) {
				user.setLoggedIn(true);
				status = "success";
				object.addProperty("role", user.getTblrole().getRoleId());
				object.addProperty("userName", user.getFirstName());
				object.addProperty("firstName", user.getFirstName());
				object.addProperty("lastName", user.getLastName());
				object.addProperty("country", "");

			} else if ((user = this.authenticationService.authenticatUser(loginPO)) == null) {
				status = "Invalid User Name or Password";
				object.addProperty("role", "");
			}

			session.setAttribute("user", user);
			object.addProperty("status", status);

		} catch (Exception e) {
			ApplicationLogging.publish("IN login authentication the exception raised is " + e.getMessage(), e);
			throw new Exception("IN login authentication the exception raised is " + e.getMessage(), e);
		}

		return object.toString();
	}

}
