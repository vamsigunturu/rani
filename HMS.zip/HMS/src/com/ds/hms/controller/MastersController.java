package com.ds.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ds.hms.po.CategoryMasterPO;
import com.ds.hms.po.DoctorPO;
import com.ds.hms.po.HospitalItemMasterPO;
import com.ds.hms.po.PatientPO;
import com.ds.hms.pojo.TblCategory;
import com.ds.hms.pojo.Tbldoctor;
import com.ds.hms.pojo.Tblpatient;
import com.ds.hms.pojo.Tbluser;
import com.ds.hms.service.MasterService;

@Controller
public class MastersController {

	@Autowired
	private MasterService masterService;
	
	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/doctordetails/save", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String saveDoctorDetails(@RequestBody DoctorPO doctorPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String status  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			status = this.masterService.saveDoctorDetails(doctorPO, user);

		} catch (Exception e) {
			throw new Exception("IN Saving the doctor details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"status\" : \""+status+"\"}";
	}
	
	
	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/doctordetails/fetch", method = RequestMethod.GET)
	public @ResponseBody List<Tbldoctor> fetchDoctorDetails(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		List<Tbldoctor>  tbldoctors = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			tbldoctors = this.masterService.fetchDoctorDetails(user);

		} catch (Exception e) {
			throw new Exception("IN fetching the doctor details exception raised is " + e.getMessage(), e);
		}
		
		return tbldoctors;
	}
	
	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/patientdetails/save", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String savePatientDetails(@RequestBody PatientPO patientPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String status  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			status = this.masterService.savePatientDetails(patientPO, user);

		} catch (Exception e) {
			throw new Exception("IN Saving the Patient details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"status\" : \""+status+"\"}";
	}

	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/patientcode/fetch", method = RequestMethod.GET)
	public @ResponseBody String fetchPatientCode(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String patientCode  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			patientCode = this.masterService.fetchPatientCode(user);

		} catch (Exception e) {
			throw new Exception("IN Saving the Patient details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"patientCode\" : \""+patientCode+"\"}";
	}
	
	
	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/patientdetails/fetch", method = RequestMethod.GET)
	public @ResponseBody List<Tblpatient> fetchPatientDetails(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		List<Tblpatient> tblpatients  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			tblpatients = this.masterService.fetchPatientDetails(user);

		} catch (Exception e) {
			throw new Exception("IN Fetching the Patient details exception raised is " + e.getMessage(), e);
		}
		
		return tblpatients;
	}
	
	
	/**
	 * 
	 * @param categoryMasterPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/categorymaster/save", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String saveCategoryMasterDetails(@RequestBody CategoryMasterPO categoryMasterPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String status  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			status = this.masterService.saveCategoryMasterDetails(categoryMasterPO, user);

		} catch (Exception e) {
			throw new Exception("IN Saving the Category details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"status\" : \""+status+"\"}";
	}
	
	/**
	 * 
	 * @param doctorPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/categorymaster/fetch", method = RequestMethod.GET)
	public @ResponseBody List<TblCategory> fetchCategoryMasterDetails(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		List<TblCategory> tblCategories  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			tblCategories = this.masterService.fetchCategoryMasterDetails(user);

		} catch (Exception e) {
			throw new Exception("IN Fetching the Category Master details exception raised is " + e.getMessage(), e);
		}
		
		return tblCategories;
	}
	
	/**
	 * 
	 * @param categoryMasterPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/categorymaster/save", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String saveCategoryMasterDetails(@RequestBody CategoryMasterPO categoryMasterPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String status  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			status = this.masterService.saveCategoryMasterDetails(categoryMasterPO, user);

		} catch (Exception e) {
			throw new Exception("IN Fetching the Category details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"status\" : \""+status+"\"}";
	}
	
	
	/**
	 * 
	 * @param hospitalItemMasterPO
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/hospitalitemmaster/save", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String saveHospitalItemMasterDetails(@RequestBody HospitalItemMasterPO hospitalItemMasterPO, HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession(false);
		String status  = null;
		Tbluser user = (Tbluser) session.getAttribute("user");

		try {
			
			status = this.masterService.saveHospitalItemMasterDetails(hospitalItemMasterPO, user);

		} catch (Exception e) {
			throw new Exception("IN Saving the Hospital Item Master details exception raised is " + e.getMessage(), e);
		}
		
		return "{ \"status\" : \""+status+"\"}";
	}

}
