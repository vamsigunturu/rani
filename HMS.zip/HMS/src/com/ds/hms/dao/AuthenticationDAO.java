package com.ds.hms.dao;

import com.ds.hms.constants.ApplicationConstants;
import com.ds.hms.constants.GlobalMessages;
import com.ds.hms.constants.QueryConstants;
import com.ds.hms.po.LoginPO;
import com.ds.hms.pojo.Tbluser;

public interface AuthenticationDAO extends ApplicationConstants, GlobalMessages, QueryConstants {

	/**
	 * 
	 * @param loginPO
	 * @return
	 * @throws Exception
	 */
	Tbluser authenticatUser(LoginPO loginPO) throws Exception;

}
