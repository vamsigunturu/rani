package com.ds.hms.utils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.ds.hms.constants.ApplicationConstants;

public class ApplicationContextListner implements ServletContextListener, ApplicationConstants {

	
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("context application destroyed");

	}

	
	public void contextInitialized(ServletContextEvent arg0) {

		try {
			
			Logging.setErrorAppender(LOG_PATH);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
