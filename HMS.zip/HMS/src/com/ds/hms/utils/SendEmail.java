package com.ds.hms.utils;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.ds.hms.constants.GlobalMessages;

public class SendEmail implements GlobalMessages {

	private static final String SMTP_HOST_NAME = mailBundle.getString("SMTP_HOST_NAME");
	private static final String SMTP_AUTH_USER = mailBundle.getString("SMTP_AUTH_USER");
	private static final String SMTP_AUTH_PWD = mailBundle.getString("SMTP_AUTH_PWD");
	private static final String emailFromAddress = mailBundle.getString("FROM_ADDRESS");
	private static final String SMTP_PORT = mailBundle.getString("mail.smtp.port");
	private static String sub = "Test Message";
	private static String MsgTxt = "";

	public static void main(String args[]) {

		SendEmail mail = new SendEmail();
		String tos[] = { "vishnuj@dhasri.com" };
		String filenames[] = null;
		String sub = "";
		String body = "Testing mail";
		
		try {
			
			System.out.println("Before sending mail");

			mail.postMail(tos, null, null, sub, body, filenames);

			System.out.println("after sending mail");
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	@SuppressWarnings("restriction")
	public void postMail(String to[], String cc[], String bcc[], String subject, String bodymsg, String[] filenames)
			throws MessagingException, UnsupportedEncodingException {
		boolean debug = false;
		java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		sub = subject;
		MsgTxt = bodymsg;

		// Set the host smtp address
		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", SMTP_HOST_NAME);
		props.put("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.port", SMTP_PORT);
		Authenticator auth = new SMTPAuthenticator();
		Session session = Session.getDefaultInstance(props, auth);
		session.setDebug(debug);

		// create a message
		Message msg = new MimeMessage(session);
		// set the from Address
		InternetAddress addressFrom = new InternetAddress(emailFromAddress, "::. Physician Dispensing .::");
		msg.setFrom(addressFrom);

		// set the To Address
		if (to != null) {
			InternetAddress[] addressTo = new InternetAddress[to.length];
			for (int i = 0; i < to.length; i++) {
				addressTo[i] = new InternetAddress(to[i]);
			}
			msg.setRecipients(Message.RecipientType.TO, addressTo);
		}
		// set the CC Address
		if (cc != null) {
			InternetAddress[] addressCC = new InternetAddress[cc.length];
			for (int i = 0; i < cc.length; i++) {
				addressCC[i] = new InternetAddress(cc[i]);
			}
			msg.setRecipients(Message.RecipientType.CC, addressCC);
		}
		// set the BCC Address
		if (bcc != null) {
			InternetAddress[] addressBCC = new InternetAddress[bcc.length];
			for (int i = 0; i < bcc.length; i++) {
				addressBCC[i] = new InternetAddress(bcc[i]);
			}
			msg.setRecipients(Message.RecipientType.BCC, addressBCC);
		}
		// Setting the Subject and Content Type
		msg.setSubject(sub);
		if (filenames == null)
			msg.setContent(getMultipart());
		else {
			File[] attachments = new File[filenames.length];
			for (int i = 0; i < filenames.length; i++)
				attachments[i] = new File(filenames[i]);
			msg.setContent(createAttachment(attachments));

		}
		Transport.send(msg);
	}

	/**
	 * SimpleAuthenticator is used to do simple authentication when the SMTP
	 * server requires it.
	 */
	private static Multipart getMultipart() throws MessagingException {

		Multipart multi = new MimeMultipart("mixed");
		multi.addBodyPart(createContent());
		return multi;

	}

	private static BodyPart createHtmlBody() throws MessagingException {
		BodyPart html = new MimeBodyPart();
		html.setContent(MsgTxt, "text/html;charset=gbk");
		return html;
	}

	private static BodyPart createContent() throws MessagingException {
		BodyPart content = new MimeBodyPart();
		Multipart relate = new MimeMultipart("related");
		relate.addBodyPart(createHtmlBody());

		content.setContent(relate);
		return content;
	}

	private static Multipart createAttachment(File[] files) throws MessagingException {

		Multipart multi = new MimeMultipart("mixed");

		for (int i = 0; i < files.length; i++) {
			BodyPart attach = new MimeBodyPart();
			DataSource ds = new FileDataSource(files[i]);
			attach.setDataHandler(new DataHandler(ds));
			attach.setFileName(ds.getName());
			multi.addBodyPart(attach);

		}
		multi.addBodyPart(createContent());
		return multi;
	}

	private class SMTPAuthenticator extends javax.mail.Authenticator {

		public PasswordAuthentication getPasswordAuthentication() {
			String username = SMTP_AUTH_USER;
			String password = SMTP_AUTH_PWD;
			return new PasswordAuthentication(username, password);
		}
	}
}
