package com.ds.hms.utils;

import java.sql.Timestamp;

import org.apache.log4j.Appender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.EnhancedPatternLayout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Logging {

	private static Logger logger = Logger.getRootLogger();
	private static Appender appender = null;

	// information
	public static void publish(Object messgae, Throwable t) {
		logger.info(messgae, t);
	}

	public static void publish(Throwable t) {
		logger.info("Exception/Error", t);
	}

	public static void publish(Object messgae) {
		logger.info(messgae);
	}

	// error
	public static void error(Object messgae, Throwable t) {
		logger.error(messgae, t);
	}

	public static void error(Throwable t) {
		logger.error("Exception/Error", t);
	}

	public static void error(Object messgae) {
		logger.error(messgae);

	}

	// debug
	public static void debug(Object messgae, Throwable t) {
		logger.debug(messgae, t);
	}

	public static void debug(Throwable t) {
		logger.debug("Exception/Error", t);
	}

	public static void debug(Object messgae) {
		logger.debug(messgae);

	}

	// fatal
	public static void fatal(Object messgae, Throwable t) {
		logger.fatal(messgae, t);
	}

	public static void fatal(Throwable t) {
		logger.fatal("Exception/Error", t);
	}

	public static void fatal(Object messgae) {
		logger.fatal(messgae);

	}

	// warning
	public static void warn(Object messgae, Throwable t) {
		logger.warn(messgae, t);
	}

	public static void warn(Throwable t) {
		logger.warn("Exception/Error", t);
	}

	public static void warn(Object messgae) {
		logger.warn(messgae);

	}

	public static void setErrorAppender(String applicationPath) throws Exception {

		try {

			logger = Logger.getRootLogger();
			logger.setLevel(Level.ERROR);
			appender = new DailyRollingFileAppender(
					new EnhancedPatternLayout("%n ################ Entry Date And Time : %d{DATE} ################ %n %n [%t] - %m %n %n *********** Stack Trace *********** %n %n Exception Information : %n %n"),
					applicationPath + "/logs/Error_"+ CurrentDate.getdate(new Timestamp(System.currentTimeMillis()), "dd-MM-yyyy") + ".log",
					"yyyy-MM-dd");

		} catch (Exception e) {
			e.printStackTrace();
		}
		BasicConfigurator.configure(appender);
	}

}
