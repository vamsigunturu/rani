package com.ds.hms.utils;

import java.sql.Timestamp;

public class Checker {

	public static void main(String args[]) throws Exception {

		String password = "admin@123";
		String passwordEnc = AesEncrypt.encrypt(password);
		// String passwordDec = AesEncrypt.decrypt(password);

		System.out.println("Plain Text : " + password);
		System.out.println("Encrypted Text : " + passwordEnc);
		// System.out.println("Decrypted Text : " + passwordDec);

		System.out.println(new Timestamp(System.currentTimeMillis()));
	}
}
