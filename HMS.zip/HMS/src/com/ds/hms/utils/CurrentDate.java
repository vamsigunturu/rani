package com.ds.hms.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class CurrentDate {

	// Getting Year for given timestamp
	public static int getYear(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.YEAR);
	}

	// Getting MONTH for given timestamp
	public static int getMonth(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.MONTH) + 1;
	}

	// Getting DATE for given timestamp
	public static int getDate(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.DATE);
	}

	// Getting HOUR for given timestamp
	public static int getHour(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.HOUR);
	}

	// Getting MINUTE for given timestamp
	public static int getMinute(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.MINUTE);
	}

	// Getting SECOND for given timestamp
	public static int getSecond(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.SECOND);
	}

	// Getting MILLISECOND for given timestamp
	public static int getMilliSecond(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.MILLISECOND);
	}

	// Getting AM/PM for given timestamp
	public static int getTimePeriod(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp.getTime());
		return calendar.get(Calendar.AM_PM);
	}

	public static int getyear() {
		Calendar cal = Calendar.getInstance();
		return cal.get(Calendar.YEAR);

	}

	public static Date getnextdate(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // add 15 days
		date = cal.getTime();
		return date;
	}

	public static Date getnextdate1(Date date, int noofmonths) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) + noofmonths)); // add
																			// noofmonths
		date = cal.getTime();
		return date;
	}

	public static Timestamp getNextDateBasedOnYear(long date, int noOfYear) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		cal.set(Calendar.YEAR, (cal.get(Calendar.YEAR) + noOfYear)); // add no
																		// of
																		// year
		return new Timestamp(cal.getTimeInMillis());
	}

	public static Timestamp getNextDateBasedOnMonth(long date, int noOfMonth) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) + noOfMonth)); // add
																		// no of
																		// months
		return new Timestamp(cal.getTimeInMillis());
	}

	public static Timestamp getNextDateBasedOnDay(long date, int noOfDay) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		cal.set(Calendar.DATE, (cal.get(Calendar.DATE) + noOfDay)); // add no of
																	// days
		return new Timestamp(cal.getTimeInMillis());
	}

	public static Timestamp getNextDate(long date, int noOfDay, int noOfMonth, int noOfYear) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		cal.set(Calendar.YEAR, (cal.get(Calendar.YEAR) + noOfYear)); // add no
																		// of
																		// year
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) + noOfMonth)); // add
																		// no of
																		// months
		cal.set(Calendar.DATE, (cal.get(Calendar.DATE) + noOfDay)); // add
																	// noofmonths
		return new Timestamp(cal.getTimeInMillis());
	}

	public static String getdate(Date date) {
		Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		return formatter.format(date);

	}

	public static String getdate(Date date, String format) {
		try {
			if (date != null) {
				Format formatter = new SimpleDateFormat(format);
				return formatter.format(date);
			} else {
				return "----";
			}
		} catch (Exception e) {
			return "-----";
		}

	}

	public static String getdatetime(Date date) {
		Format formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
		return formatter.format(date);

	}

	public static Timestamp gettimestamp() {

		return new Timestamp(new Date().getTime());

	}

	public static Date getstrtodate(String date, String format) {
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			return formatter.parse(date);
		} catch (Exception e) {
			return null;
		}

	}

	public static String getconvertdate(Timestamp timestamp) {
		try {
			Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
			calendar.setTimeInMillis(timestamp.getTime());

			String s = calendar.get(Calendar.YEAR) + "";
			return (calendar.get(Calendar.MONTH) + 1) + "/" + s.substring(2, s.length());
		} catch (Exception e) {
			return null;
		}

	}

	public static String getDateFormat(Timestamp timestamp, String dateFormat) {
		try {
			DateFormat df = new SimpleDateFormat(dateFormat);
			return df.format(timestamp.getTime());
		} catch (Exception e) {
			return null;
		}
	}

	public static Date getconvertdate(String date) {
		try {

			String dates[] = null;
			String cdate = null;
			if (date.contains("/")) {
				dates = date.split("/");
			} else if (date.contains("-")) {
				dates = date.split("-");
			}
			if (dates != null) {
				for (int i = 0; i < dates.length; i++) {
					if (dates[i].length() == 1) {
						dates[i] = "0" + dates[i];
					}

				}

				cdate = dates[0] + "/" + dates[1] + "/" + dates[2];
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

				return formatter.parse(cdate);
			}

		} catch (Exception e) {
			return null;
		}
		return null;

	}

	public static Integer getmonthnumber(String month) {

		List<String> months = new ArrayList<String>();
		months.add("Jan");
		months.add("Feb");
		months.add("Mar");
		months.add("Apr");
		months.add("May");
		months.add("Jun");
		months.add("Jul");
		months.add("Aug");
		months.add("Sep");
		months.add("Oct");
		months.add("Nov");
		months.add("Dec");
		return months.indexOf(month);
	}

	public static void main(String args[]) {
		System.out.println(getconvertdate("31/05/2012"));
	}

	public static Timestamp getTimeStamp(String fromDate) {
		Timestamp timestamp = null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date parsedDate = dateFormat.parse(fromDate);
			timestamp = new java.sql.Timestamp(parsedDate.getTime());
		} catch (Exception e) {// this generic but you csan control another
								// types of exception
			e.printStackTrace();
		}
		return timestamp;
	}
}
